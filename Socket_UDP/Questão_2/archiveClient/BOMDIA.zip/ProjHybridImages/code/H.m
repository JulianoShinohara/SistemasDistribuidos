function res = H(u,v,s,d0)
res = exp(-((D(u,v,s))^2/(2*d0^2)));
end
