function [hybrid_image,low_frequencies,high_frequencies] = gen_hybrid_image_fft( image1, image2, cutoff_frequency )
% Inputs:
% - image1 -> The image from which to take the low frequencies.
% - image2 -> The image from which to take the high frequencies.
% - cutoff_frequency -> The standard deviation, in pixels, of the Gaussian 
%                       blur that will remove high frequencies.
%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remove the high frequencies from image1 by blurring it. The amount of
% blur that works best will vary with different image pairs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
low_frequencies = [];

image1 = im2single(image1);
image2 = im2single(image2);

figure, imshow(image1);
b = padarray(image1, size(image1),0 ,"post");
c = im2double(b(:,:,1:3));
d = fft2(c);
d = fftshift(d);
figure, imshow(uint8(abs(d)));

[n m o] = size(c);
h = zeros([n,m]);
for i = 1:n
    for j = 1:m
        h(i,j) = H(i,j,size(c),cutoff_frequency);
    end
end
figure, imshow(im2uint8(h));

g = d.*h;

g = ifftshift(g);
at = ifft2(g);
at = abs(at);
[x y o] = size(image1);
atc = at(1:x,1:y);
low_frequencies = im2uint8(atc);

low_frequencies = im2single(low_frequencies);
figure, imshow(low_frequencies);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remove the low frequencies from image2. The easiest way to do this is to
% subtract a blurred version of image2 from the original version of image2.
% This will give you an image centered at zero with negative values.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
high_frequencies = [];
low_frequencies2 = [];

figure, imshow(image2);
b2 = padarray(image2, size(image2),0 ,"post");
c2 = im2double(b2(:,:,1:3));
d2 = fft2(c2);
d2 = fftshift(d2);
figure, imshow(uint8(abs(d2)));

[n2, m2, o2] = size(c2);
h2 = zeros([n2,m2]);
for i = 1:n2
    for j = 1:m2
        h2(i,j) = H(i,j,size(c2),cutoff_frequency);
    end
end
figure, imshow(im2uint8(h2));

g2 = d2.*h2;

g2 = ifftshift(g2);
at2 = ifft2(g2);
at2 = abs(at2);
[x2, y2, o2] = size(image2);
atc2 = at2(1:x2,1:y2);
low_frequencies2 = im2uint8(atc2);
figure, imshow(low_frequencies2);

low_frequencies2 = im2single(low_frequencies2);

high_frequencies = image2 - low_frequencies2;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Combine the high frequencies and low frequencies
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hybrid_image = [];

hybrid_image = low_frequencies + high_frequencies;

