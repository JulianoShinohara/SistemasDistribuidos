function res = D(u,v,s)
res = sqrt((u-s(1)/2)^2+(v-s(2)/2)^2);
end
